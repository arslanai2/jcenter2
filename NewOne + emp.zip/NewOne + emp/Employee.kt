package com.translateall.language.free.translator.dictionary.speechtext.learnenglish.ui.activities

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
@Entity(tableName = "employees")
data class Employee(
  @PrimaryKey(autoGenerate = true)
    val id : Int = 0,
    val name2 : String
)
@Dao
interface EmployeeDao{
    @Insert
    fun insert111(emp :Employee)
    @Query("DELETE FROM employees")
    fun deleteAllEmployees()
}
@Database(entities = [Employee::class], version = 1)
abstract class EmpDatabase : RoomDatabase(){
    abstract fun daomustbeusedfromthis():EmployeeDao
}