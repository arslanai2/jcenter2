package com.translateall.language.free.translator.dictionary.speechtext.learnenglish.ui.activities

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.room.Room
class NewOne : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = Room.databaseBuilder(this, EmpDatabase::class.java, "aaa5").allowMainThreadQueries().build()
//        db.daomustbeusedfromthis().insert111(Employee(name2 = "a"))
//        db.daomustbeusedfromthis().insert111(Employee(name2 = "s"))
//        db.daomustbeusedfromthis().insert111(Employee(name2 = "d"))
//        db.daomustbeusedfromthis().insert111(Employee(name2 = "f"))
//        db.daomustbeusedfromthis().insert111(Employee(name2 = "g"))
        db.daomustbeusedfromthis().deleteAllEmployees()
        db.daomustbeusedfromthis().insert111(Employee(name2 = "adsd"))
    }
}