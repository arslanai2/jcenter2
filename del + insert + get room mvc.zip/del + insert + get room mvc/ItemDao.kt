package com.example.ars

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
//https://play.google.com/store/apps/details?id=org.fossify.contacts
//https://github.com/nafiskabbo/Contacts-v2/tree/master/app/src/main/res
@Dao
interface ItemDao {
    @Query("SELECT * from arslan1")
    fun getData() : List<ItemModel>


    //change 1 insert
    @Insert
    fun insertItem(item: ItemModel)


    @Query("DELETE FROM arslan1")
    fun deleteAll()

}