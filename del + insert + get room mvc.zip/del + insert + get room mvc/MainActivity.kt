package com.example.ars

import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.room.Room

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Build DB (no controller class)
        val db = Room.databaseBuilder(
            this,
            AppDatabase::class.java,
            "ars_db5"
        ).allowMainThreadQueries() // Simple use (no coroutines)
            .build()

        // INSERT ONE VALUE STATICALLY
        db.itemDao().insertItem(ItemModel(38,"sdf"))
        db.itemDao().insertItem(ItemModel(34,"dhy"))
        db.itemDao().insertItem(ItemModel(35,"d"))
        db.itemDao().insertItem(ItemModel(36,"f"))
        db.itemDao().insertItem(ItemModel(37,"ggg"))

        db.itemDao().deleteAll()

        // Call DAO directly
        val list = db.itemDao().getData()

        // Log values
        for (item in list) {
            Log.d("ARS_MAIN", "Item ID = ${item.id}")
        }
    }
}
