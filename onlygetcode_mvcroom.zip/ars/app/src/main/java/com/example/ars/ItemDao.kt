package com.example.ars

import androidx.room.Dao
import androidx.room.Query

@Dao
interface ItemDao {
    @Query("SELECT * from arslan1")
    fun getData() : List<ItemModel>
}