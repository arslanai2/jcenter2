package com.example.ars

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "arslan1")
class ItemModel (
    @PrimaryKey(autoGenerate = true)
    val id : Int =0
)