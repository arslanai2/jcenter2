package com.example.ars

import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.room.Room

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Build DB (no controller class)
        val db = Room.databaseBuilder(
            this,
            AppDatabase::class.java,
            "ars_db"
        ).allowMainThreadQueries() // Simple use (no coroutines)
            .build()

        // Call DAO directly
        val list = db.itemDao().getData()

        // Log values
        for (item in list) {
            Log.d("ARS_MAIN", "Item ID = ${item.id}")
        }
    }
}
